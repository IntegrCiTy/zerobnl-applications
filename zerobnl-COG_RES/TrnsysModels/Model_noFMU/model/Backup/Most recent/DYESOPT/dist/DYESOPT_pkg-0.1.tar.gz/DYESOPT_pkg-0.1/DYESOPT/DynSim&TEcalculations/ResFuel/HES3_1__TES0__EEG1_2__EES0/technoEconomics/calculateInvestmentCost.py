# Calculation of Investment costs for a CHP plant

from CostFunctions.CHP_CAPEX import *

