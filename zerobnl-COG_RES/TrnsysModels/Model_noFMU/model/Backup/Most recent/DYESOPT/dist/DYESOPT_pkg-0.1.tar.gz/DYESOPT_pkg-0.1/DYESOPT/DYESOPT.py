# First the run mode is selected in this file (DYESOPT.py)
# Second the model components are selected manually from model_Choice.py


runMode = 'single'

# runMode options:
    # Single
    # Sensitivity
    # Optimization


if runMode == 'single':
    import runModel





