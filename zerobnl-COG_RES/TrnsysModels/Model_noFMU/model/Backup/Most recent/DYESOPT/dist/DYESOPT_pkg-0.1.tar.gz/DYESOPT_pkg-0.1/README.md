#DYESOPT

Below are some notes to consider before running the python version of DYESOPT:

1.	You have to run the tool as administrator
2.	Install it in root C:\
3.	Check the dependencies file
